﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
  public  class HospitalCD
    {
        public List<hospital> GetHospital()
        {
            using (pruebaDB db = new pruebaDB())
            {
                return db.hospital.ToList();
            }
        }
    }
}
