﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
   public class EliminarCD
    {
      public bool EliminarDoctor(int Cod_doctor)
      {
          try{
            using (pruebaDB db = new pruebaDB()) {
                var datos = (from q in db.doctor where q.Cod_doctor == Cod_doctor select q).First();
                    db.doctor.Remove(datos);
                    db.SaveChanges();
                }
          return true;
          }
          
          catch(Exception){
              return false;
              throw;
          } 
     }


      public bool EliminarPaciente(int Cod_paciente)
      {
          try
          {
              using (pruebaDB db = new pruebaDB())
              {
                  var datos = (from Q in db.paciente where Q.Cod_paciente == Cod_paciente select Q).First();
                  db.paciente.Remove(datos);
                  db.SaveChanges();
              }
              return true;
          }

          catch (Exception)
          {
              return false;
              throw;
          } 
      }
    }
}
