﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
namespace CapaDatos
{
    public class PacienteCD
    {
        public List<paciente> GetPaciente()
        {

            using (pruebaDB db = new pruebaDB())
            {
                return db.paciente.ToList();
            }
        }


        /// <summary>
        /// Registro de pacientes 
        /// </summary>
        /// Parametros recibidos
        /// <param name="Cod_paciente"></param>
        /// <param name="NombreCompleto"></param>
        /// <param name="Num_SeguroSocial"></param>
        /// <param name="cod_postal"></param>
        /// <param name="Telefono"></param>
        /// <param name="Sexo"></param>
        public void AlmacenarPaciente(string Cod_paciente, string NombreCompleto, string Num_SeguroSocial, string cod_postal, string Telefono, string Sexo)
        {
            using (pruebaDB db = new pruebaDB())
            {
                    paciente oPaciente = new paciente();
                    oPaciente.Cod_paciente = Convert.ToInt32(Cod_paciente);
                    oPaciente.NombreCompleto = NombreCompleto;
                    oPaciente.Num_SeguroSocial = Convert.ToDecimal(Num_SeguroSocial);
                    oPaciente.cod_postal = Convert.ToDecimal(cod_postal);
                    oPaciente.Telefono = Convert.ToDecimal(Telefono);
                    oPaciente.Sexo = Sexo;
                    db.paciente.Add(oPaciente);
                    db.SaveChanges();
            }
        }
    }
}
