﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;

namespace CapaDatos
{
  public  class DoctorCD
    {
        public List<doctor> GetDoctor()
        {
            using (pruebaDB db = new pruebaDB())
            {
                return db.doctor.ToList();
            }
        }


        public void AlmacenarDoctor(string Cod_doctor, string NombreCompleto, string NoCredencial, string especialidad, string id_hospital, string Telefono, string Sexo)
        {
            using (pruebaDB db = new pruebaDB())
            {
                doctor oDoctor = new doctor();
                oDoctor.Cod_doctor = Convert.ToInt32(Cod_doctor);
                oDoctor.NombreCompleto = NombreCompleto;
                oDoctor.Num_credencial = Convert.ToDecimal(NoCredencial);
                oDoctor.Especialidad = especialidad;
                oDoctor.Id_hospital = Convert.ToInt32(id_hospital);
                oDoctor.Telefono = Convert.ToDecimal(Telefono);
                oDoctor.Sexo = Sexo;
                db.doctor.Add(oDoctor);
                db.SaveChanges();
            }
        }
    }
}
