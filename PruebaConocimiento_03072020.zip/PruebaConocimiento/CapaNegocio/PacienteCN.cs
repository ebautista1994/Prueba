﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using CapaDatos;


namespace CapaNegocio
{
   public class PacienteCN
    {
       PacienteCD obj = new PacienteCD();
       EliminarCD ObjDelete = new EliminarCD();
       public List<paciente> GetPacienteCN() {
           return obj.GetPaciente();
       }
       /// <summary>
       /// REGISTRO PACIENTE
       /// </summary>
       /// PARAMETROS:
       /// <param name="Cod_paciente"></param>
       /// <param name="NombreCompleto"></param>
       /// <param name="Num_SeguroSocial"></param>
       /// <param name="cod_postal"></param>
       /// <param name="Telefono"></param>
       /// <param name="Sexo"></param>
       /// <returns></returns>
       public bool PostPacienteCN(string Cod_paciente, string NombreCompleto, string Num_SeguroSocial, string cod_postal, string Telefono, string Sexo)
       {
           try {
               obj.AlmacenarPaciente(Cod_paciente, NombreCompleto, Num_SeguroSocial, cod_postal, Telefono, Sexo);
               return true;
               }

           catch (Exception) {
                ///Error log
               return false;
           }
       }

       /// <summary>
       /// ELIMINAR PACIENTE 
       /// PARAMETROS:
       /// </summary>
       /// <param name="Cod_Paciente"></param>
       /// <returns></returns>
       public bool EliminarPacienteCN(int Cod_Paciente)
       {
           try
           {
               return ObjDelete.EliminarPaciente(Cod_Paciente);
           }
           catch (Exception)
           {
               throw;
               //Log
           }
       }
    }
}
