﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using CapaDatos;

namespace CapaNegocio
{
  public  class HospitalCN
    {
        HospitalCD obj = new HospitalCD();
        public List<hospital> GetHospitalCN()
        {
            return obj.GetHospital();
        }
    }
}
