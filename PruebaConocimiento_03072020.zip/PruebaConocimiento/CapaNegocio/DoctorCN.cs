﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaEntidad;
using CapaDatos;

namespace CapaNegocio
{
  public  class DoctorCN
    {
        DoctorCD obj = new DoctorCD();
        EliminarCD ObjDelete = new EliminarCD();
        public List<doctor> GetDoctorCN()
        {
            return obj.GetDoctor();
        }
        /// <summary>
        /// REGISTRO DOCTOR
        /// </summary>
        /// PARAMETROS:
        /// <param name="Cod_paciente"></param>
        /// <param name="NombreCompleto"></param>
        /// <param name="Num_SeguroSocial"></param>
        /// <param name="cod_postal"></param>
        /// <param name="Telefono"></param>
        /// <param name="Sexo"></param>
        /// <returns></returns>
        public bool PostDoctorCN(string Cod_doctor, string NombreCompleto, string NoCredencial, string especialidad, string id_hospital, string Telefono, string Sexo)
        {
            try
            {
                obj.AlmacenarDoctor(Cod_doctor, NombreCompleto, NoCredencial, especialidad, id_hospital, Telefono, Sexo);
                return true;
            }

            catch (Exception)
            {
                ///Error log
                return false;
            }
        }

        public bool EliminarDoctorCN(int Cod_doctor) {
            try {
                return ObjDelete.EliminarDoctor(Cod_doctor); 
            }
            catch (Exception) {
                throw;
                //Log
            }
        }
    }
}
